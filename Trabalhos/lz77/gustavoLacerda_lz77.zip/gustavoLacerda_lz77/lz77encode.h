#ifndef LZ77ENCODE_H
#define LZ77ENCODE_H
// protótipo da função de compressão
void compress(char *str, int janela);
#endif