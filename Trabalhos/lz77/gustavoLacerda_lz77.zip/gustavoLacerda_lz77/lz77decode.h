#ifndef LZ77DECODE_H
#define LZ77DECODE_H
// protótipo da função de descompressão
void decompress(char *compressed_str);
#endif