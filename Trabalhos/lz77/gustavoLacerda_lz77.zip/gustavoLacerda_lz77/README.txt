## Trabalho de Progamação de computadores 1 ##
- Biblioteca de compressão lz77 utilizando 'c'

### Como utilizar a Biblioteca ###
1° Possuir os arquivos lz77.a, lz77decode.h e lz77encode.h na mesma pasta de seu programa
2° Incluir os algoritmos em seu programa com #include ' "lz77decode.h" ' e ' #include "lz77decode.h" '
3° Compilar o programa com ' gcc <programa> -o <nome_executavel> lz77.a '

## Feito por ##
Gustavo Cunha Lacerda (ABI - Computação, 2°Sem)

